# Spud's Sharpness

This mod adds a simple building piece called the Grindstone that allows you to sharpen your weapon which will give them a buff that makes them deal 30% more damage for 10 minutes.


# Installation

1. Install BepInEx.
2. Extract the mod download into <Valheim>/BepInEx/plugins folder so the .dll is inside of the plugins folder.
3. BepInEx will load the plugin and all should work. Enjoy!

# How to use 

To use the Grindstone you simply build the Grindstone which is located in the crafting tab and interact with it while holding the weapon you want to then you reequip the weapon and you should receive the sharpness effect 

# Crafting recipes  

Grindstone
10 wood, 1 Sharpening Stone, 4 copper

On TODO list:

1. Make the Sharpness effect configurable 
2. Make crafting cost configurable 
3. fix how the timer on the effect works

# Bug Reports
https://www.nexusmods.com/valheim/mods/1016
if you find bugs u can report them here