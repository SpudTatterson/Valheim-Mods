# InvisHelm

Helmet are invisible but still give armor.
now with quick buttons
H- hide/show helmet
(can change in config)
# Installation

1. Install BepInEx.
2. Extract the mod download into <Valheim>/BepInEx/plugins folder so the .dll is inside of the plugins folder.
3. BepInEx will load the plugin and all should work. Enjoy!

https://www.nexusmods.com/valheim/mods/192?tab=description 
if you find bugs u can report them here