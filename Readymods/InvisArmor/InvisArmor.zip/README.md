# InvisArmor

Chestplate, Utilty, pants and Capes are invisible but still give armor.
Can now hide every item individually 
pants are still shown by default if u want to hide pants go to config and change hide pants to true
Quick buttons
H- hide/show Armor
(can change in config)
# Installation

1. Install BepInEx.
2. Extract the mod download into <Valheim>/BepInEx/plugins folder so the .dll is inside of the plugins folder.
3. BepInEx will load the plugin and all should work. Enjoy!

For bug reports 
https://www.nexusmods.com/valheim/mods/410

Should be used in conjunction with my other mod InvisHelm
https://www.nexusmods.com/valheim/mods/192
https://valheim.thunderstore.io/package/Spud91584b8508e84879/InvisHelm/