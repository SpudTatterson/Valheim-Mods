# Spud's Forsaken Totems

Adds craft-able totems to the game that when equipped give you forsaken abilities as a passive power.
Eikthyr Totem now upgradeable check nexus page for more info.

to change crafing diffculty check config
(1- easy 2- hard)

Now with accurate 3d models thanks to Ato

# Installation

1. Install BepInEx.
2. Extract the mod download into <Valheim>/BepInEx/plugins folder so the .dll is inside of the plugins folder.
3. BepInEx will load the plugin and all should work. Enjoy!

On TODO list:

1. Make the effects configurable 
2. Make crafting cost configurable 

https://www.nexusmods.com/valheim/mods/715
if you find bugs u can report them here